﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HRLeaveWebApplication
{
    public class AppSettings
    {
        public string AzureFunctionURL { get; set; }

    }
}
